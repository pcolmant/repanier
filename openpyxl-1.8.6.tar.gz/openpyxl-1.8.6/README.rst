openpyxl
========

openpyxl is a Python library to read/write Excel 2010 xlsx/xlsm files.

It was born from lack of existing library to read/write natively from Python
the new Office Open XML format.

All kudos to the PHPExcel team as openpyxl is based on PHPExcel
http://www.phpexcel.net/


Mailing List
============

Official user list can be found on
http://groups.google.com/group/openpyxl-users


Official documentation
======================

The homepage is http://openpyxl.readthedocs.org
You will find:

* every installation methods
* the official documentation
* code examples
* instructions for contributing
